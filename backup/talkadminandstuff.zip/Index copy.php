<?php
$secret = "supersecret";
if(isset($_COOKIE['secret']) && $_COOKIE['secret'] == $secret)
{
}
else
{

if(!isset($_GET['secret']))
{
die('pwd mismatch.1');
}
if($_GET['secret'] == $secret)
{

setcookie('secret', $secret,  60 * 60 * 24 * 60 + time()); 

}
else
{

die('pwd mismatch.2');


}
}